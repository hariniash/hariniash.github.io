
{
    title: {
        text: `Stock Price ${ticker} ${year}-${month}-${date}`,
        margin:40,
    },
    subtitle:{
        text: `<br/><a href="https://finnhub.io/" target="_blank">Source: Finnhub</a>`,
        useHTML:true,
    },
    yAxis: [{
        labels: {
            align: 'right',
        },
        title: {
            text: 'Stock Price',
        },
        opposite:false,
    }, {
        labels: {
            align: 'left',
        },
        title: {
            text: 'Volume'
        },
        opposite:true,
    }],

    rangeSelector: {
        buttons: [
            {
                type: 'day',
                count: 7,
                text: '7d'
            },{
                type: 'day',
                count: 15,
                text: '15d'
            },{
                type: 'month',
                count: 1,
                text: '1m'
            },{
                type: 'month',
                count: 3,
                text: '3m'
            },
            {
                type: 'month',
                count: 6,
                text: '6m'
            }
        ],
        selected: 4,
        inputEnabled: false
    },
    navigation: {
        buttonOptions: {
            enabled: true
        }
    },
    series: [{
        type: 'area',
        name: 'Stock Price',
        data: data.stockPrice,
        fillColor: {
            linearGradient: {
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 1
            },
            stops: [
                [0, Highcharts.getOptions().colors[0]],
                [1, Highcharts.color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
            ]
        },
        threshold: null
    }, {
        type: 'column',
        name: 'Volume',
        data: data.volume,
        yAxis: 1,
        color:"#434348",
    }]
}