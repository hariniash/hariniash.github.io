import { Component, OnInit, Input } from '@angular/core';
import { ApiCallsService } from '../api-calls.service';
import { faCaretDown, faCaretUp } from '@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-portfolio-card',
  templateUrl: './portfolio-card.component.html',
  styleUrls: ['./portfolio-card.component.css']
})
export class PortfolioCardComponent implements OnInit {
  @Input("buyStockAlert") buyStockAlert: Function = ()=>{};
  @Input("sellStockAlert") sellStockAlert: Function = ()=>{};
  @Input("transactionUpdate") transactionUpdate:Function = ()=>{};
  faCaretDown = faCaretDown;
  faCaretUp = faCaretUp;

  constructor(private apiCalls: ApiCallsService) { }

  ngOnInit(): void {
  }

}
